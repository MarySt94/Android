package com.example.myapplication


interface Animal {
        val age: Int
        val weight: Int
}
interface Dog: Animal{
        val bite: DogBite
}
interface Cat: Animal{
        val behavior: CatBehavior
}

enum class DogBite{
        STRAIGHT, OVERSHOT, UNDERSHOT
}

enum class CatBehavior{
        ACTIVE, PASSIVE
}

class Corgi(override val weight: Int, override val age: Int): Dog{
        val num = (0..2).random()
        override val bite: DogBite= DogBite.values()[num]
}

class Husky(override val weight: Int, override val age: Int): Dog{
        val num = (0..2).random()
        override val bite: DogBite= DogBite.values()[num]
}

class ScottishCat(override val weight: Int, override val age: Int): Cat{
        val num = (0..1).random()
        override val behavior: CatBehavior= CatBehavior.values()[num]
}
class SiameseCat(override val weight: Int, override val age: Int): Cat{
        val num = (0..1).random()
        override val behavior: CatBehavior= CatBehavior.values()[num]
}

class Zoo(override val age:Int,override val weight: Int, val breed: String): Animal{
        fun DefineAnimal(): Animal{
                return when (breed) {
                        "husky" -> Husky(weight, age)
                        "corgi" -> Corgi(weight, age)
                        "scottish_cat" -> ScottishCat(weight, age)
                        "siamese_cat" -> SiameseCat(weight, age)
                        else -> throw IllegalArgumentException("Wrong answer.Try again!")
                }
        }

}
